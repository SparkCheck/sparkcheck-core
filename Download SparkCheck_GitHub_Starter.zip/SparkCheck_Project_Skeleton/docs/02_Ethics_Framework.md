# Ethics Framework

This file outlines SparkCheck’s commitment to:
- Human-first signal design
- Non-invasive neurofeedback loops
- Consent-aware AI protocols
- Trauma-informed system logic
